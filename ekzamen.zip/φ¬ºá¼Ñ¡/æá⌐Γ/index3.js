document.getElementById('registrationForm').addEventListener('submit', function(event) {
  event.preventDefault();

  var username = document.getElementById('username').value;
  var email = document.getElementById('email').value;
  var password = document.getElementById('password').value;
  var errorMessage = document.getElementById('errorMessage');

  
  if (!username || !email || !password) {
    errorMessage.textContent = 'Пожалуйста, заполните все поля.';
    return;
  }

  
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    errorMessage.textContent = 'Username can only contain letters and numbers.';
    return;
  }

 
  if (!/\S+@\S+\.\S+/.test(email)) {
    errorMessage.textContent = 'Имя пользователя может содержать только буквы и цифры.';
    return;
  }

 
  errorMessage.textContent = 'Регистрация успешна!';
});
